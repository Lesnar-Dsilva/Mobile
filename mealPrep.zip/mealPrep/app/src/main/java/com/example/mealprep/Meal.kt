package com.example.mealprep

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName="meals_table")
data class Meal(
    @PrimaryKey var idMeal:Int?,
    var strMeal:String?,//The "?" allows this variable to be assigned a null value
    var strDrinkAlternate: String?,
    var strCategory: String?,
    var strArea: String?,
    var strInstructions: String?,
    var strMealThumb: String?,
    var strTags: String?,
    var strYoutube: String?,
    var strIngredients: String?,
    var strMeasures: String?,
    var strSource: String?,
    var strImageSource: String?,
    var strCreativeCommonsConfirmed: String?,
    var dateModified: String?
    )