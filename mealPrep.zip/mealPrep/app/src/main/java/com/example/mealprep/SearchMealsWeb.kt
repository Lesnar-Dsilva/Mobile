package com.example.mealprep

import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.os.StrictMode
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.room.Room
import com.android.volley.Request
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import java.net.URL

class SearchMealsWeb : AppCompatActivity() {
    private lateinit var mealDAO: MealDAO
    private lateinit var searchInput: EditText
    private lateinit var searchBtn: Button
    private var retrievedMeals = mutableListOf<Meal>()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.search_meals_web)
        val db = Room.databaseBuilder(applicationContext,MealDatabase::class.java,"meal_database").build()
        mealDAO = db.mealDao()
        searchBtn = findViewById(R.id.search_meals_web_btn)
        searchInput = findViewById(R.id.search_meals_web_input)
        searchBtn.setOnClickListener {
            retrievedMeals.clear()
            findViewById<LinearLayout>(R.id.mealsWebHorizontalLayout).removeAllViews()
            Toast.makeText(applicationContext,"Please wait while the images load.",Toast.LENGTH_SHORT).show()
            getID(searchInput.text.toString())
        }
    }
    private fun getID(x:String) {
        val filterUrl = "https://www.themealdb.com/api/json/v1/1/search.php?s=$x"

        val q = Volley.newRequestQueue(this)
        Thread{
            val sR = StringRequest(Request.Method.GET,filterUrl,
                {response ->
                    if(response != "{\"meals\":null}") {
                        for (m in response.split("},{")) {
                            getMeal(
                                m.replace("{\"meals\":[{", "").replace("}]}", "").replace("\",\""," | ").replace("\":\""," = ").replace("\"","").split(" | ")[0].split(" = ")[1]
                            )
                            println(
                                "ID: " + m.replace("{\"meals\":[{", "").replace("}]}", "").replace("\",\""," | ").replace("\":\""," = ").replace("\"","").split(" | ")[0].split(" = ")[1]
                            )
                        }
                    }else{
                        Toast.makeText(applicationContext, "No meals with $x in their name",Toast.LENGTH_SHORT).show()
                    }
                },
                { println("An error occurred.") })
            q.add(sR)}.start()
    }
    private fun getMeal(x:String){
        var idMeal = 0
        var strMeal = ""
        var strDrinkAlternate = ""
        var strCategory = ""
        var strArea = ""
        var strInstructions = ""
        var strMealThumb = ""
        var strTags = ""
        var strYoutube = ""
        val strIngredients = mutableListOf<String>()
        val strMeasures = mutableListOf<String>()
        var strIM = mutableListOf<String>()
        var strSource = ""
        var strImageSource = ""
        var strCreativeCommonsConfirmed = ""
        var dateModified = ""
        val mealUrl = "https://www.themealdb.com/api/json/v1/1/lookup.php?i=$x"
        val q = Volley.newRequestQueue(this)
        Thread{
            val sR = StringRequest(Request.Method.GET,mealUrl,
                {response ->
                    //Splits the response at each meal retrieved
                    for(i in 0 until response.split("},{").size){
                        val l = response.split("},{")[i].replace("{\"meals\":[{","").replace("}]}","").replace("null","\"null\"").replace("\":\""," = ").replace("\",\""," | ").replace("\"","").replace("\\/","/").split(" | ")
                        println(l)
                        //Variables used to insert data into database START
                        for(index in l.indices){
                            if(l[index].split(" = ")[0] == "idMeal"){
                                idMeal = l[index].split(" = ")[1].toInt()
                            }
                            if(l[index].split(" = ")[0] =="strMeal"){
                                strMeal = l[index].split(" = ")[1].replace("\\\\u([0-9A-Fa-f]{4})".toRegex()) {
                                    String(Character.toChars(it.groupValues[1].toInt(radix = 16)))
                                }
                            }
                            if(l[index].split(" = ")[0] =="strDrinkAlternate"){
                                strDrinkAlternate = l[index].split(" = ")[1]
                            }
                            if(l[index].split(" = ")[0] =="strCategory"){
                                strCategory = l[index].split(" = ")[1]
                            }
                            if(l[index].split(" = ")[0] =="strArea"){
                                strArea = l[index].split(" = ")[1]
                            }

                            if(l[index].split(" = ")[0] =="strInstructions"){
                                strInstructions = l[index].split(" = ")[1].replace("\\r\\n",System.getProperty("line.separator")).replace("\\\\u([0-9A-Fa-f]{4})".toRegex()) {
                                    String(Character.toChars(it.groupValues[1].toInt(radix = 16)))
                                }
                            }
                            if(l[index].split(" = ")[0] =="strMealThumb"){
                                strMealThumb = l[index].split(" = ")[1]
                            }
                            if(l[index].split(" = ")[0] =="strTags"){
                                strTags = l[index].split(" = ")[1]
                            }
                            if(l[index].split(" = ")[0] =="strYoutube"){
                                strYoutube = l[index].split(" = ")[1]
                            }
                            //Combined to form data in the strIM variable START
                            if(l[index].split(" = ")[0].contains("strIngredient") && l[index].split(" = ")[1] != "null" && l[index].split(" = ")[1] != "" && l[index].split(" = ")[1] != " "){
                                strIngredients.add(l[index].split(" = ")[1].replace("\\\\u([0-9A-Fa-f]{4})".toRegex()) {
                                    String(Character.toChars(it.groupValues[1].toInt(radix = 16)))
                                })
                            }
                            if(l[index].split(" = ")[0].contains("strMeasure")&& l[index].split(" = ")[1] != "null" && l[index].split(" = ")[1] != "" && l[index].split(" = ")[1] != " "){
                                strMeasures.add(l[index].split(" = ")[1].replace("\\\\u([0-9A-Fa-f]{4})".toRegex()) {
                                    String(Character.toChars(it.groupValues[1].toInt(radix = 16)))
                                })
                            }
                            //Combined to form data in the strIM variable END
                            if(l[index].split(" = ")[0] =="strSource"){
                                strSource = l[index].split(" = ")[1]
                            }
                            if(l[index].split(" = ")[0] =="strImageSource"){
                                strImageSource = l[index].split(" = ")[1]
                            }
                            if(l[index].split(" = ")[0] =="strCreativeCommonsConfirmed"){
                                strCreativeCommonsConfirmed = l[index].split(" = ")[1]
                            }
                            if(l[index].split(" = ")[0] =="dateModified"){
                                dateModified = l[index].split(" = ")[1]
                            }
                        }
                    }
                    for(i in 0 until strIngredients.size){
                        if(i < strMeasures.size && i < strIngredients.size){
                            strIM.add(strMeasures[i] + " " + strIngredients[i])
                        }else if(i <  strIngredients.size && i > strMeasures.size){
                            strIM.add(strIngredients[i])
                        }
                    }
                    retrievedMeals.add(Meal(idMeal,strMeal,strDrinkAlternate,strCategory,strArea,strInstructions,strMealThumb,strTags,strYoutube,strIngredients.toString().replace("[","").replace("]",""),strMeasures.toString().replace("[","").replace("]",""),strSource,strImageSource,strCreativeCommonsConfirmed,dateModified))
//
                    println(Meal(idMeal,strMeal,strDrinkAlternate,strCategory,strArea,strInstructions,strMealThumb,strTags,strYoutube,strIngredients.toString().replace("[","").replace("]",""),strMeasures.toString().replace("[","").replace("]",""),strSource,strImageSource,strCreativeCommonsConfirmed,dateModified))
                    println("Size: ${retrievedMeals.size} Newest Meal: ${retrievedMeals[retrievedMeals.size-1]}")
//
                    val policy = StrictMode.ThreadPolicy.Builder().permitAll().build()
                    StrictMode.setThreadPolicy(policy)

                    val horizontalLayout = findViewById<LinearLayout>(R.id.mealsWebHorizontalLayout)
                    val verticalLayout = LinearLayout(this)

                    val mealImage = ImageView(this)
                    val mealName = TextView(this)

                    //Vertical layout to display recipe, etc. for a meal START
                    verticalLayout.orientation = LinearLayout.VERTICAL
                    verticalLayout.layoutParams = ViewGroup.LayoutParams(resources.displayMetrics.widthPixels,ViewGroup.LayoutParams.MATCH_PARENT)
                    verticalLayout.id = retrievedMeals[retrievedMeals.size-1].idMeal.hashCode()
                    //Vertical layout to display recipe, etc. END

                    //Thumbnail image for meal START
                    mealImage.setImageBitmap(BitmapFactory.decodeStream(URL(strMealThumb).openConnection().getInputStream()))
                    mealImage.layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.MATCH_PARENT)
                    mealImage.scaleType = ImageView.ScaleType.CENTER_CROP
                    //Thumbnail image for meal END

                    //Display name for meal START
                    mealName.text = strMeal
                    mealName.setTextColor(Color.BLACK)
                    mealName.setTypeface(null, Typeface.BOLD)
                    mealName.gravity = Gravity.CENTER
                    mealName.layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT)
                    mealName.setBackgroundColor(Color.RED)
                    //Thumbnail image for meal END

                    verticalLayout.addView(mealName)
                    verticalLayout.addView(mealImage)

                    //Event-listener for each meal displayed START
                    verticalLayout.setOnClickListener{
                        val view = View.inflate(this, R.layout.popup_meals,null)
                        val width = LinearLayout.LayoutParams.WRAP_CONTENT
                        val height = LinearLayout.LayoutParams.WRAP_CONTENT

                        val txt = view.findViewById<TextView>(R.id.mealInfo)
                        val popupWindow = PopupWindow(view,width,height,true)

                        popupWindow.showAtLocation(findViewById(R.id.mealsWebLayout),Gravity.CENTER,0,0)
                        txt.text = "DrinkAlternate: " + strDrinkAlternate + "\n\n" + "Category: " + strCategory + "\n\n" + "Area: " + strArea + "\n\n" + "Ingredients:\n" + strIM.toString().replace("[","").replace("]","") + "\n\n" + "Instructions: \n" + strInstructions
                    }
                    //Event-listener for each meal displayed END
                    horizontalLayout.addView(verticalLayout)
                },
                { println("An error occurred.") })
            q.add(sR)
        }.start()

    }
}

//1. Retrieve meals with their name matching the input string from web service (API) from https://www.themealdb.com/api/json/v1/1/search.php?s=[xxxxx].

//2. Display results in same activity.