package com.example.mealprep

import androidx.room.*

@Dao
interface MealDAO {
    @Insert
    suspend fun insertMeal(meal: Meal)

    @Query("SELECT * FROM meals_table")
    fun getAllMeals(): List<Meal>

    @Query("SELECT count(*)!=0 FROM meals_table WHERE idMeal = :id")
    fun exists(id: Int):Boolean

    @Update
    suspend fun updateMeal(meal: Meal)

    @Delete
    suspend fun deleteMeal(meal: Meal)
}