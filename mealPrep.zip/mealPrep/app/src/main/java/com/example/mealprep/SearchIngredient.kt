package com.example.mealprep

import android.annotation.SuppressLint
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.StrictMode
import android.util.Log
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.room.Room
import com.android.volley.Request
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.net.URL

class SearchIngredient : AppCompatActivity() {
    private lateinit var mealDAO: MealDAO
    private var retrievedMeals = mutableListOf<Meal>()
    private var favList = mutableListOf<Meal>()
    private lateinit var retrieveIngredient:Button
    private lateinit var saveToDatabase: Button
    private lateinit var ingredient:EditText
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.search_ingredient)
        val db = Room.databaseBuilder(applicationContext,MealDatabase::class.java,"meal_database").build()
        mealDAO = db.mealDao()
        retrieveIngredient = findViewById(R.id.retrieveIngredient)
        ingredient = findViewById(R.id.searchIngredient)
        retrieveIngredient.setOnClickListener {
            if(ingredient.text.toString().isNotEmpty()) {
                Toast.makeText(applicationContext,"Please wait while the images load.",Toast.LENGTH_SHORT).show()
                findViewById<LinearLayout>(R.id.horizontalLayout).removeAllViews()
                retrievedMeals.clear()
                favList.clear()
                Thread{getID(ingredient.text.toString())}.start()
            }else{
                Toast.makeText(applicationContext, "Please type a ingredient.", Toast.LENGTH_SHORT)
                    .show()
            }
        }
        saveToDatabase = findViewById(R.id.saveToDatabase)
        saveToDatabase.setOnClickListener {
            println(favList)
            Log.i("PRINT","********** Inserting "+favList.size+" Meals **********")
            for(meal in favList){
                Thread {
                    if (!(mealDAO.exists(meal.idMeal.toString().toInt()))) {
                        lifecycleScope.launch(Dispatchers.IO) {
                            Log.i(
                                "PRINT",
                                "********** Inserting " + meal.strMeal + " START **********"
                            )
                            mealDAO.insertMeal(meal)
                            Log.i(
                                "PRINT",
                                "********** Inserting " + meal.strMeal + " END **********"
                            )
                        }
                    }else{
                        Handler(Looper.getMainLooper()).post{
                            Toast.makeText(
                                applicationContext,
                                meal.strMeal+" has already been added.",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    }
                }.start()
            }
            Log.i("PRINT","********** Inserted "+favList.size+" Meals **********")
        }

    }
    private fun getID(x:String) {
        val filterUrl = "https://www.themealdb.com/api/json/v1/1/filter.php?i=$x"

        val q = Volley.newRequestQueue(this)
        Thread{
            val sR = StringRequest(Request.Method.GET,filterUrl,
                {response ->
                    if(response != "{\"meals\":null}") {
                        for (m in response.split("},{")) {
                            getMeal(
                                m.replace("{\"meals\":[{", "").replace("}]}", "").replace("\",\""," | ").replace("\":\""," = ").replace("\"","").split(" | ")[m.replace("{\"meals\":[{", "").replace("}]}", "").replace("\",\""," | ").replace("\":\""," = ").replace("\"","").split(" | ").size - 1].split(" = ")[1]
                            )
                            println(
                                "ID: " + m.replace("{\"meals\":[{", "").replace("}]}", "").replace("\",\""," | ").replace("\":\""," = ").replace("\"","").split(" | ")[m.replace("{\"meals\":[{", "").replace("}]}", "").replace("\",\""," | ").replace("\":\""," = ").replace("\"","").split(" | ").size - 1].split(" = ")[1]
                            )
                        }
                    }else{
                        Toast.makeText(applicationContext, "No meals with $x in their ingredients",Toast.LENGTH_SHORT).show()
                    }
                },
                { println("An error occurred.") })
            q.add(sR)}.start()
    }
    @SuppressLint("SetTextI18n")
    private fun getMeal(x:String){
        var idMeal = 0
        var strMeal = ""
        var strDrinkAlternate = ""
        var strCategory = ""
        var strArea = ""
        var strInstructions = ""
        var strMealThumb = ""
        var strTags = ""
        var strYoutube = ""
        val strIngredients = mutableListOf<String>()
        val strMeasures = mutableListOf<String>()
        var strIM = mutableListOf<String>()
        var strSource = ""
        var strImageSource = ""
        var strCreativeCommonsConfirmed = ""
        var dateModified = ""
        val mealUrl = "https://www.themealdb.com/api/json/v1/1/lookup.php?i=$x"
        val q = Volley.newRequestQueue(this)
        Thread{
            val sR = StringRequest(Request.Method.GET,mealUrl,
                {response ->
                    //Splits the response at each meal retrieved
                    for(i in 0 until response.split("},{").size){
                        val l = response.split("},{")[i].replace("{\"meals\":[{","").replace("}]}","").replace("null","\"null\"").replace("\":\""," = ").replace("\",\""," | ").replace("\"","").replace("\\/","/").split(" | ")
                        println(l)
                        //Variables used to insert data into database START
                        for(index in l.indices){
                            if(l[index].split(" = ")[0] == "idMeal"){
                                idMeal = l[index].split(" = ")[1].toInt()
                            }
                            if(l[index].split(" = ")[0] =="strMeal"){
                                strMeal = l[index].split(" = ")[1].replace("\\\\u([0-9A-Fa-f]{4})".toRegex()) {
                                    String(Character.toChars(it.groupValues[1].toInt(radix = 16)))
                                }
                            }
                            if(l[index].split(" = ")[0] =="strDrinkAlternate"){
                                strDrinkAlternate = l[index].split(" = ")[1]
                            }
                            if(l[index].split(" = ")[0] =="strCategory"){
                                strCategory = l[index].split(" = ")[1]
                            }
                            if(l[index].split(" = ")[0] =="strArea"){
                                strArea = l[index].split(" = ")[1]
                            }
                            if(l[index].split(" = ")[0] =="strInstructions"){
                                strInstructions = l[index].split(" = ")[1].replace("\\r\\n",System.getProperty("line.separator")).replace("\\\\u([0-9A-Fa-f]{4})".toRegex()) {
                                    String(Character.toChars(it.groupValues[1].toInt(radix = 16)))
                                }
                            }
                            if(l[index].split(" = ")[0] =="strMealThumb"){
                                strMealThumb = l[index].split(" = ")[1]
                            }
                            if(l[index].split(" = ")[0] =="strTags"){
                                strTags = l[index].split(" = ")[1]
                            }
                            if(l[index].split(" = ")[0] =="strYoutube"){
                                strYoutube = l[index].split(" = ")[1]
                            }
                            //Combined to form data in the strIM variable START
                            if(l[index].split(" = ")[0].contains("strIngredient") && l[index].split(" = ")[1] != "null" && l[index].split(" = ")[1] != "" && l[index].split(" = ")[1] != " "){
                                strIngredients.add(l[index].split(" = ")[1].replace("\\\\u([0-9A-Fa-f]{4})".toRegex()) {
                                    String(Character.toChars(it.groupValues[1].toInt(radix = 16)))
                                })
                            }
                            if(l[index].split(" = ")[0].contains("strMeasure")&& l[index].split(" = ")[1] != "null" && l[index].split(" = ")[1] != "" && l[index].split(" = ")[1] != " "){
strMeasures.add(l[index].split(" = ")[1].replace("\\\\u([0-9A-Fa-f]{4})".toRegex()) {
    String(Character.toChars(it.groupValues[1].toInt(radix = 16)))
})
                            }
                            //Combined to form data in the strIM variable END
                            if(l[index].split(" = ")[0] =="strSource"){
                                strSource = l[index].split(" = ")[1]
                            }
                            if(l[index].split(" = ")[0] =="strImageSource"){
                                strImageSource = l[index].split(" = ")[1]
                            }
                            if(l[index].split(" = ")[0] =="strCreativeCommonsConfirmed"){
                                strCreativeCommonsConfirmed = l[index].split(" = ")[1]
                            }
                            if(l[index].split(" = ")[0] =="dateModified"){
                                dateModified = l[index].split(" = ")[1]
                            }
                        }
                    }
                    for(i in 0 until strIngredients.size){
                        if(i < strMeasures.size && i < strIngredients.size){
                            strIM.add(strMeasures[i] + " " + strIngredients[i])
                        }else if(i <  strIngredients.size && i > strMeasures.size){
                            strIM.add(strIngredients[i])
                        }
                    }
                    //Variables used to insert data into database END
                    retrievedMeals.add(Meal(idMeal,strMeal,strDrinkAlternate,strCategory,strArea,strInstructions,strMealThumb,strTags,strYoutube,strIngredients.toString().replace("[","").replace("]",""),strMeasures.toString().replace("[","").replace("]",""),strSource,strImageSource,strCreativeCommonsConfirmed,dateModified))
//
                    println(Meal(idMeal,strMeal,strDrinkAlternate,strCategory,strArea,strInstructions,strMealThumb,strTags,strYoutube,strIngredients.toString().replace("[","").replace("]",""),strMeasures.toString().replace("[","").replace("]",""),strSource,strImageSource,strCreativeCommonsConfirmed,dateModified))
                    println("Size: ${retrievedMeals.size} Newest Meal: ${retrievedMeals[retrievedMeals.size-1]}")
//
                    val policy = StrictMode.ThreadPolicy.Builder().permitAll().build()
                    StrictMode.setThreadPolicy(policy)

                    val horizontalLayout = findViewById<LinearLayout>(R.id.horizontalLayout)
                    val verticalLayout = LinearLayout(this)

                    val mealImage = ImageView(this)
                    val mealName = TextView(this)
                    var btnToggle = 1

                    //Vertical layout to display recipe, etc. for a meal START
                    verticalLayout.orientation = LinearLayout.VERTICAL
                    verticalLayout.layoutParams = ViewGroup.LayoutParams(resources.displayMetrics.widthPixels,ViewGroup.LayoutParams.MATCH_PARENT)
                    verticalLayout.id = retrievedMeals[retrievedMeals.size-1].idMeal.hashCode()
                    //Vertical layout to display recipe, etc. END

                    //Thumbnail image for meal START
                    mealImage.setImageBitmap(BitmapFactory.decodeStream(URL(strMealThumb).openConnection().getInputStream()))
                    mealImage.layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.MATCH_PARENT)
                    mealImage.scaleType = ImageView.ScaleType.CENTER_CROP
                    //Thumbnail image for meal END

                    //Display name for meal START
                    mealName.text = strMeal
                    mealName.setTextColor(Color.BLACK)
                    mealName.setTypeface(null, Typeface.BOLD)
                    mealName.gravity = Gravity.CENTER
                    mealName.layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT)
                    mealName.setBackgroundColor(Color.RED)
                    //Thumbnail image for meal END

                    verticalLayout.addView(mealName)
                    verticalLayout.addView(mealImage)

                    //Event-listener for each meal displayed START
                    verticalLayout.setOnClickListener{
                        val view = View.inflate(this, R.layout.popup,null)
                        val width = LinearLayout.LayoutParams.WRAP_CONTENT
                        val height = LinearLayout.LayoutParams.WRAP_CONTENT

                        val btn = view.findViewById<Button>(R.id.save)
                        val txt = view.findViewById<TextView>(R.id.mealInfo)
                        val popupWindow = PopupWindow(view,width,height,true)

                        popupWindow.showAtLocation(findViewById(R.id.ingredientLayout),Gravity.CENTER,0,0)
                        txt.text = "DrinkAlternate: " + strDrinkAlternate + "\n\n" + "Category: " + strCategory + "\n\n" + "Area: " + strArea + "\n\n" + "Ingredients:\n" + strIM.toString().replace("[","").replace("]","") + "\n\n" + "Instructions: \n" + strInstructions
                        if(btnToggle == 0){
                            btn.setBackgroundColor(Color.RED)
                            btn.text = "Remove Meal From List"
                        }
                        if(btnToggle == 1){

                            btn.setBackgroundColor(Color.GREEN)
                            btn.text = "Save Meal To List"
                        }
                        //SAVE/REMOVE button for favourites list START
                        btn.setOnClickListener {
                            if(btnToggle == 1) {
                                for(meal in retrievedMeals) {
                                    if (verticalLayout.id == meal.idMeal) {
                                        println("SAVED: "+meal.idMeal)
                                        favList.add(meal)
                                        Toast.makeText(applicationContext,"Added "+meal.strMeal+" to the list",Toast.LENGTH_SHORT).show()
                                    }
                                }

                                btn.setBackgroundColor(Color.RED)
                                btn.text = "Remove Meal From List"
                                mealName.setBackgroundColor(Color.GREEN)
                                popupWindow.dismiss()
                                btnToggle = 0
                            }else if(btnToggle == 0){
                                for(meal in retrievedMeals) {
                                    if (verticalLayout.id == meal.idMeal) {
                                        println("REMOVED: "+meal.idMeal)
                                        favList.remove(meal)
                                        Toast.makeText(applicationContext,"Removed "+meal.strMeal+" from the list",Toast.LENGTH_SHORT).show()
                                    }
                                }
                                btn.setBackgroundColor(Color.GREEN)
                                btn.text = "Save Meal To List"
                                mealName.setBackgroundColor(Color.RED)
                                popupWindow.dismiss()
                                btnToggle = 1
                            }

                        }
                        //SAVE/REMOVE button for favourites list END
                    }
                    //Event-listener for each meal displayed END
                    horizontalLayout.addView(verticalLayout)
                },
                { println("An error occurred.") })
            q.add(sR)
        }.start()

    }
}
//1. Retrieve Meals button should request meals containing input string in their Ingredients from https://www.themealdb.com/api/json/v1/1/filter.php?i=[xxxxx].

//2. Display results in same activity.

//3. Save meals to Database button saves the retrieved meals to the SQLite database of the device (using Kotlin's Room library).

//References:
//1. https://stackoverflow.com/questions/45219379/how-to-make-an-api-request-in-kotlin
//2. https://www.google.com/url?client=internal-element-cse&cx=000521750095050289010:zpcpi1ea4s8&q=https://developer.android.com/training/volley/simple&sa=U&ved=2ahUKEwj6vZ_gvff9AhXgavEDHcv9BVQQFnoECAEQAQ&usg=AOvVaw08Ht3f0X5rLf-28bPdhpiw
//3. https://stackoverflow.com/questions/7186040/insert-a-view-dynamically-in-a-horizontalscrollview-in-android
//4. https://stackoverflow.com/questions/18953632/how-to-set-image-from-url-for-imageview
//5. https://stackoverflow.com/questions/6343166/how-can-i-fix-android-os-networkonmainthreadexception
//6. https://developer.android.com/reference/kotlin/android/os/StrictMode.ThreadPolicy.Builder
//7. https://stackoverflow.com/questions/27807243/nested-vertical-layout-in-horizontal-layout
//8. https://stackoverflow.com/questions/432037/how-do-i-center-text-horizontally-and-vertically-in-a-textview
//9. https://stackoverflow.com/a/69220212
//10. https://www.youtube.com/watch?v=cxQvQE1mksI