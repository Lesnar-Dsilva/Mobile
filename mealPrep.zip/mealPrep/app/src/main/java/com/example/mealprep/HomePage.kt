package com.example.mealprep

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.util.Log
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.isVisible
import androidx.lifecycle.lifecycleScope
import androidx.room.Room
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlin.system.exitProcess

class HomePage : AppCompatActivity() {
    private lateinit var mealDAO: MealDAO
    private lateinit var addMealsBtn:Button
    private lateinit var searchIngredientsBtn:Button
    private lateinit var searchDBMeals:Button
    private lateinit var searchDBMealsWeb:Button
    private lateinit var reset:Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.home_page)
        //Create database
        val db = Room.databaseBuilder(applicationContext,MealDatabase::class.java,"meal_database").build()
        mealDAO = db.mealDao()

        addMealsBtn = findViewById(R.id.addMealsBtn)
        addMealsBtn.setOnClickListener {
            Thread {
                if (!(mealDAO.exists(52771) && mealDAO.exists(52947) && mealDAO.exists(52965))) {
                    addMeals()
                } else {
                    Handler(Looper.getMainLooper()).post{
                        Toast.makeText(
                            applicationContext,
                            "Meals have already been added.",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }
            }.start()
        }

        searchIngredientsBtn = findViewById(R.id.searchIngredientsBtn)
        searchIngredientsBtn.setOnClickListener {
            val intent = Intent(this, SearchIngredient::class.java)
            startActivity(intent)
        }
        searchDBMeals = findViewById(R.id.searchMealsBtn)
        searchDBMeals.setOnClickListener {
            val intent = Intent(this, SearchMeals::class.java)
            startActivity(intent)
        }
        searchDBMealsWeb = findViewById(R.id.searchMealsWebBtn)
        searchDBMealsWeb.setOnClickListener {
            val intent = Intent(this, SearchMealsWeb::class.java)
            startActivity(intent)
        }
        //DELETE DATABASE BUTTON (EXPERIMENTAL) START
        reset = findViewById(R.id.reset)
        reset.isVisible = false
        reset.setOnClickListener {
            //Delete local database
            applicationContext.deleteDatabase("meal_database")
            finish()
            startActivity(intent)
        }
        //DELETE DATABASE BUTTON (EXPERIMENTAL) END
    }
private fun addMeals(){
    lifecycleScope.launch(Dispatchers.IO){
        //INSERT NEW MEAL INTO DATABASE START
        Log.i("PRINT","********** Inserting 3 Meals **********")
        mealDAO.insertMeal(Meal(52771,"Spicy Arrabiata Penne",null,"Vegetarian","Italian","Bring a large pot of water to a boil. Add kosher salt to the boiling water, then add the pasta. Cook according to the package instructions, about 9 minutes.\r\nIn a large skillet over medium-high heat, add the olive oil and heat until the oil starts to shimmer. Add the garlic and cook, stirring, until fragrant, 1 to 2 minutes. Add the chopped tomatoes, red chile flakes, Italian seasoning and salt and pepper to taste. Bring to a boil and cook for 5 minutes. Remove from the heat and add the chopped basil.\r\nDrain the pasta and add it to the sauce. Garnish with Parmigiano-Reggiano flakes and more basil and serve warm.","https://www.themealdb.com/images/media/meals/ustsqw1468250014.jpg","Pasta,Curry","https://www.youtube.com/watch?v=1IszT_guI08",
            listOf("penne rigate","olive oil","garlic","chopped tomatoes","red chile flakes","italian seasoning","basil","Parmigiano-Reggiano").joinToString(","),
            listOf("1 pound","1/4 cup","3 cloves","1 tin","1/2 teaspoon","1/2 teaspoon","6 leaves","sprinkling").joinToString(","),null,null,null,null))
        mealDAO.insertMeal(Meal(52947,"Ma Po Tofu",null,"Beef","Chinese","Add a small pinch of salt and sesame oil to minced beef. Mix well and set aside.\r\nMix 1 tablespoon of cornstarch with 2 and \u00bd tablespoons of water in a small bowl to make water starch.\r\nCut tofu into square cubes (around 2cms). Bring a large amount of water to a boil and then add a pinch of salt. Slide the tofu in and cook for 1 minute. Move out and drain.\r\nGet a wok and heat up around 2 tablespoons of oil, fry the minced meat until crispy. Transfer out beef out and leave the oil in.\r\nFry doubanjiang for 1 minute over slow fire and then add garlic, scallion white, ginger and fermented black beans to cook for 30 seconds until aroma. Then mix pepper flakes in.\r\nAdd water to the seasonings and bring to boil over high fire. Gently slide the tofu cubes. Add light soy sauce and beef.Slow the heat after boiling and then simmer for 6-8 minutes. Then add chopped garlic greens.\r\nStir the water starch and then pour half of the mixture to the simmering pot. Wait for around 30 seconds and then pour the other half. You can slightly taste the tofu and add pinch of salt if not salty enough. By the way, if you feel it is too spicy, add some sugar can milder the taste. But be carefully as the broth is very hot at this point.\r\nTransfer out when almost all the seasonings stick to tofu cubes. Sprinkle Szechuan peppercorn powder (to taste)and chopped garlic greens if using.\r\nServe immediately with steamed rice.","https://www.themealdb.com/images/media/meals/1525874812.jpg",null,"https://www.youtube.com/watch?v=IhwPQL9dFYc",
            listOf("Tofu","Minced Beef","Sesame Seed Oil","Doubanjiang","Fermented Black Beans","Pepper","Salt","Sichuan pepper","Soy Sauce","Water","Olive Oil","Scallions","Spring Onions","Garlic","Ginger","Water","Cornstarch").joinToString(","),
            listOf("450g","100g","1/2 tbs","1 1/2 tsp","1/2 tsp","1 tbs","1/2 tsp","1/2 tsp","1 tbs","400ml","2 tbs","2 chopped","4","2 cloves chopped","4 sliced","2 1/2 tbs","1 tbs").joinToString(","),"https://www.chinasichuanfood.com/mapo-tofu-recipe/",null,null,null))
        mealDAO.insertMeal(Meal(52965,"Breakfast Potatoes",null,"Breakfast","Canadian","Before you do anything, freeze your bacon slices that way when you're ready to prep, it'll be so much easier to chop!\r\nWash the potatoes and cut medium dice into square pieces. To prevent any browning, place the already cut potatoes in a bowl filled with water.\r\nIn the meantime, heat 1-2 tablespoons of oil in a large skillet over medium-high heat. Tilt the skillet so the oil spreads evenly.\r\nOnce the oil is hot, drain the potatoes and add to the skillet. Season with salt, pepper, and Old Bay as needed.\r\nCook for 10 minutes, stirring the potatoes often, until brown. If needed, add a tablespoon more of oil.\r\nChop up the bacon and add to the potatoes. The bacon will start to render and the fat will begin to further cook the potatoes. Toss it up a bit! The bacon will take 5-6 minutes to crisp.\r\nOnce the bacon is cooked, reduce the heat to medium-low, add the minced garlic and toss. Season once more. Add dried or fresh parsley. Control heat as needed.\r\nLet the garlic cook until fragrant, about one minute.\r\nJust before serving, drizzle over the maple syrup and toss. Let that cook another minute, giving the potatoes a caramelized effect.\r\nServe in a warm bowl with a sunny side up egg!","https://www.themealdb.com/images/media/meals/1550441882.jpg","Breakfast,Brunch","https://www.youtube.com/watch?v=BoD0TIO9nE4",
            listOf("Potatoes","Olive Oil","Bacon","Garlic Clove","Maple Syrup","Parsley","Salt","Pepper","Allspice").joinToString(","),listOf("3 Medium","1 tbs","2 strips","Minced","1 tbs","Garnish","Pinch","Pinch","To taste").joinToString(","),"http://www.vodkaandbiscuits.com/2014/03/06/bangin-breakfast-potatoes/",
            null,null,null))
        Log.i("PRINT","********** Inserted 3 Meals **********")
        //INSERT NEW MEAL INTO DATABASE END

        //RETRIEVE ALL ENTRIES IN DATABASE START
        val meals = mealDAO.getAllMeals()
        Log.i("PRINT","********** ${meals.size} meals available START **********")
        for(meal in meals){
            Log.i("PRINT","id: ${meal.idMeal} strMeal: ${meal.strMeal} strDrinkAlternate: ${meal.strDrinkAlternate} strCategory: ${meal.strCategory} strArea: ${meal.strArea} strInstructions: ${meal.strInstructions} strMealThumb: ${meal.strMealThumb} strTags: ${meal.strTags} strYouTube: ${meal.strYoutube} strIngredients: ${meal.strIngredients} strSource: ${meal.strSource} strImageSource: ${meal.strImageSource} strCreativeCommonsConfirmed: ${meal.strCreativeCommonsConfirmed} dateModified: ${meal.dateModified}")
        }
        Log.i("PRINT","********** ${meals.size} meals available END **********")
        //RETRIEVE ALL ENTRIES IN DATABASE END
    }
}
}

//Goals:
//1. Add Meals to DBB button saves a few meals to an SQLite database locally to the device (using Kotlin's Room library).
//2. Search for Meals By Ingredient has two buttons and a textbox whose string input will be used to request meals from the Web service.
//2.a Save meals to Database saves all the selected meals in the local database
//2.b All the retrieved meals have thumbnail images
//3. Search for Meals contains a single textbox and a button. It displays all the meals that contain the input string in their name or ingredients attribute/field/column from the local datbase.
//3.a All the retrieved meals have thumbnail images
//4. Search for Meals (Web) contains a textbox and a button. It will retrieve meals that contain the input string in their names from the Web service.
//4.a All the retrieved meals have thumbnail images

//2023-03-23
//1. Created activities required for project: Home_Page, SearchIngredient, SearchMeals and SearchMealsWeb

//2023-03-24
//1. Created a local SQLite database using the Room library
//2. Implemented functionality for "Add Meals to DB" button, adding 3 meals to the database.

//2023-03-25
//1. Implemented functionality for "Search for Meals By Ingredient" button.
//2. Designed the "Search for Meals By Ingredient" activity.

//2023-03-26
//1. Implemented functionality for "Save meals to Database" and "Search for Meals" button.
//2. Designed the "Save meals to Database" and "Search for Meals" activities.

//2023-03-27
//1. "Search for Meals By Ingredient" is fully functional

//2023-03-28
//1. "Save meals to Database" is fully functional

//2023-03-29
//1. "Search for Meals" is fully functional

//2023-03-30
//1. Made improvements across the project to replace inefficient or brittle code.

//References
//1. https://appdevnotes.com/android-room-db-tutorial-for-beginners-in-kotlin/