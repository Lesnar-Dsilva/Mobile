package com.example.mealprep

import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.StrictMode
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.room.Room
import java.net.URL

class SearchMeals : AppCompatActivity() {
    private lateinit var mealDAO: MealDAO
    private lateinit var searchInput: EditText
    private lateinit var searchBtn: Button
    private var retrievedMeals = mutableListOf<Meal>()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.search_meals)
        val db = Room.databaseBuilder(applicationContext,MealDatabase::class.java,"meal_database").build()
        mealDAO = db.mealDao()
        searchBtn = findViewById(R.id.search_meals_btn)
        searchInput = findViewById(R.id.search_meals_input)
        searchBtn.setOnClickListener {
            retrievedMeals.clear()
            findViewById<LinearLayout>(R.id.mealsHorizontalLayout).removeAllViews()
            Toast.makeText(applicationContext,"Please wait while the images load.",Toast.LENGTH_SHORT).show()
            retrieve(searchInput.text.toString())
        }
    }
    private fun retrieve(x: String){
        Thread {
            if(mealDAO.getAllMeals().size > 0) {
                for (meal in mealDAO.getAllMeals()) {
                    var strIM = mutableListOf<String>()
                    if ((meal.strMeal.toString().lowercase()
                            .contains(x.lowercase()) || meal.strIngredients.toString().lowercase()
                            .contains(x.lowercase())) && x.length > 0
                    ) {
                        for (i in 0 until meal.strIngredients.toString().split(",").size) {
                            strIM.add(
                                meal.strMeasures.toString()
                                    .split(",")[i] + " " + meal.strIngredients.toString()
                                    .split(",")[i]
                            )
                        }
                        retrievedMeals.add(
                            Meal(
                                meal.idMeal!!,
                                meal.strMeal.toString(),
                                meal.strDrinkAlternate.toString(),
                                meal.strCategory.toString(),
                                meal.strArea.toString(),
                                meal.strInstructions.toString(),
                                meal.strMealThumb.toString(),
                                meal.strTags.toString(),
                                meal.strYoutube.toString(),
                                meal.strIngredients.toString(),
                                meal.strMeasures.toString(),
                                meal.strSource.toString(),
                                meal.strImageSource.toString(),
                                meal.strCreativeCommonsConfirmed.toString(),
                                meal.dateModified.toString()
                            )
                        )

                        println("Retrieved Meal from Database: " + retrievedMeals[retrievedMeals.size - 1])
                        //
                        println("Size: ${retrievedMeals.size} Newest Meal: ${retrievedMeals[retrievedMeals.size - 1]}")
                        val policy = StrictMode.ThreadPolicy.Builder().permitAll().build()
                        StrictMode.setThreadPolicy(policy)

                        val horizontalLayout =
                            findViewById<LinearLayout>(R.id.mealsHorizontalLayout)
                        val verticalLayout = LinearLayout(this)
                        val mealName = TextView(this)
                        val mealImage = ImageView(this)

                        //Vertical layout to display recipe, etc. for a meal START
                        verticalLayout.orientation = LinearLayout.VERTICAL
                        verticalLayout.layoutParams = ViewGroup.LayoutParams(
                            resources.displayMetrics.widthPixels,
                            ViewGroup.LayoutParams.MATCH_PARENT
                        )
                        verticalLayout.id =
                            retrievedMeals[retrievedMeals.size - 1].idMeal.hashCode()
                        //Vertical layout to display recipe, etc. END

                        //Thumbnail image for meal START
                        mealImage.setImageBitmap(
                            BitmapFactory.decodeStream(
                                URL(retrievedMeals[retrievedMeals.size - 1].strMealThumb).openConnection()
                                    .getInputStream()
                            )
                        )
                        mealImage.layoutParams = ViewGroup.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.MATCH_PARENT
                        )
                        mealImage.scaleType = ImageView.ScaleType.CENTER_CROP
                        //Thumbnail image for meal END

                        //Display name for meal START
                        mealName.text = retrievedMeals[retrievedMeals.size - 1].strMeal
                        mealName.setTextColor(Color.BLACK)
                        mealName.setTypeface(null, Typeface.BOLD)
                        mealName.gravity = Gravity.CENTER
                        mealName.layoutParams = ViewGroup.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.WRAP_CONTENT
                        )
                        mealName.setBackgroundColor(Color.RED)
                        //Thumbnail image for meal END

                        //Event-listener for each meal displayed START
                        verticalLayout.setOnClickListener {
                            val view = View.inflate(this, R.layout.popup_meals, null)
                            val width = LinearLayout.LayoutParams.WRAP_CONTENT
                            val height = LinearLayout.LayoutParams.WRAP_CONTENT

                            val txt = view.findViewById<TextView>(R.id.mealInfo)
                            val popupWindow = PopupWindow(view, width, height, true)

                            popupWindow.showAtLocation(
                                findViewById(R.id.mealsLayout),
                                Gravity.CENTER,
                                0,
                                0
                            )
                            println("strIM: " + strIM.toString().replace("[", "").replace("]", ""))
                            txt.text =
                                "DrinkAlternate: " + meal.strDrinkAlternate + "\n\n" + "Category: " + meal.strCategory + "\n\n" + "Area: " + meal.strArea + "\n\n" + "Ingredients:\n" + strIM.toString()
                                    .replace("[", "").replace(
                                    "]",
                                    ""
                                ) + "\n\n" + "Instructions: \n" + meal.strInstructions

                        }
                        //Event-listener for each meal displayed END
                        verticalLayout.addView(mealName)
                        verticalLayout.addView(mealImage)
                        Handler(Looper.getMainLooper()).post {
                            horizontalLayout.addView(verticalLayout)
                        }
                    }else{
                        if(x.isEmpty()){
                            Handler(Looper.getMainLooper()).post {
                                Toast.makeText(applicationContext, "No user input", Toast.LENGTH_SHORT)
                                    .show()
                            }
                            break
                        }
                        if (!(meal.strMeal.toString().lowercase()
                                .contains(x.lowercase()) || meal.strIngredients.toString().lowercase()
                                .contains(x.lowercase()))){
                            Handler(Looper.getMainLooper()).post {
                                Toast.makeText(applicationContext, "No meals have "+x+" in their Name or Ingredients", Toast.LENGTH_SHORT)
                                    .show()
                            }
                            break
                                }
                    }
                }
            }else{
                Handler(Looper.getMainLooper()).post {
                    Toast.makeText(applicationContext, "The database is empty", Toast.LENGTH_SHORT)
                        .show()
                }
            }
        }.start()
    }
}

//1. Request all the meals in the database (SQLite) which contain the input string in the Name or Ingredients fields of the meal in the corresponding table containing this information.

//2. The search should be case-insensitive and allow partial matches.

//3. Display meal thumbnails.