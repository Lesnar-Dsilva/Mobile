package com.example.diceroll

import android.annotation.SuppressLint
import android.os.Bundle
import android.text.Html
import android.widget.*
import androidx.appcompat.app.ActionBar
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import kotlin.random.Random
class Main : AppCompatActivity() {

    //UI variables START
    private val humanDice = listOf(R.id.hDie1, R.id.hDie2, R.id.hDie3,R.id.hDie4,R.id.hDie5)
    private val aiDice = listOf(R.id.aiDie1, R.id.aiDie2, R.id.aiDie3,R.id.aiDie4,R.id.aiDie5)
    private var eT = ""
    private var scorePressed = 0
    //UI variables END

    //HUMAN variables START
    private var humanRand = mutableListOf<Int>()
    private var humanSum = 0
    private var humanRolls = 0
    private var humanReRolls = 2
    private var humanReRollToggle = 0
    //HUMAN variables END

    //variable that allow continuity between activities START
    companion object {
        var goal: Int = 101
    }
    //variable that allow continuity between activities END

    //AI variables START
    private var aiRand = mutableListOf<Int>()
    private var aiSum = 0
    private var aiRolls = 0
    private var aiReRolls = 2
    private var aiReRollToggle = 0
    //AI variables END

    @SuppressLint("SetTextI18n", "DiscouragedApi")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val aB : ActionBar? = supportActionBar
        aB?.hide()
        findViewById<TextView>(R.id.wins).text = "Wins = YOU:${StartupActivity.humanWins} / AI:${StartupActivity.aiWins}"

        //THROW BUTTON click event listener START
        findViewById<Button>(R.id.throwBtn).setOnClickListener {
            if(humanSum >= goal && (aiSum < humanSum)){
                println("Score = YOU:${humanSum} / AI:${aiSum}")
                findViewById<TextView>(R.id.scoreTxt).text = "Score = YOU:${humanSum} / AI:${aiSum}"
                StartupActivity.humanWins++
                findViewById<TextView>(R.id.wins).text = "Wins = YOU:${StartupActivity.humanWins} / AI:${StartupActivity.aiWins}"
                val b = AlertDialog.Builder(this)
                b.setTitle(Html.fromHtml("<font color='#4f7942'>You win!</font>"))
                b.setMessage(Html.fromHtml("<font color='#006400'>You win! with a score of $humanSum against the computer with a score of $aiSum.</font>"))
                b.setPositiveButton("OK"){_,_->this.finish()}
                b.create().show()
                findViewById<Button>(R.id.throwBtn).isClickable = false
                findViewById<Button>(R.id.score).isClickable = false
            }else if(aiSum >= goal && (humanSum < aiSum)){
                findViewById<TextView>(R.id.scoreTxt).text = "Score = YOU:${humanSum} / AI:${aiSum}"
                println("Score = YOU:${humanSum} / AI:${aiSum}")
                StartupActivity.aiWins++
                findViewById<TextView>(R.id.wins).text = "Wins = YOU:${StartupActivity.humanWins} / AI:${StartupActivity.aiWins}"
                val b = AlertDialog.Builder(this)
                b.setTitle(Html.fromHtml("<font color='#ff0000'>You lose.</font>"))
                b.setMessage(Html.fromHtml("<font color='#ff0000'>You lose with a score of $humanSum against the computer with a score of $aiSum.</font>"))
                b.setPositiveButton("OK"){_,_->this.finish()}
                b.create().show()
                findViewById<Button>(R.id.throwBtn).isClickable = false
                findViewById<Button>(R.id.score).isClickable = false
            }else if(humanSum == aiSum && (aiSum >= goal && humanSum >= goal)){
                println("EQUAL Score = YOU:${humanSum} / AI:${aiSum}")
                println("HUMAN: $humanRand.joinToString()")
                println("AI: $aiRand.joinToString()")
                Toast.makeText(applicationContext, "Equal scores and rolls, all dice will be re-rolled", Toast.LENGTH_SHORT).show()
                while(humanSum == aiSum) {
                    for (r in humanRand.indices) {
                        humanSum -= humanRand[r]
                        humanRand[r] = Random.nextInt(1, 7)
                        humanSum += humanRand[r]
                        findViewById<ImageView>(humanDice[r]).setImageResource(
                            resources.getIdentifier(
                                "die_face_" + humanRand[r],
                                "drawable",
                                packageName
                            )
                        )
                    }
                    for (r in aiRand.indices) {
                        aiSum -= aiRand[r]
                        aiRand[r] = Random.nextInt(1, 7)
                        aiSum += aiRand[r]
                        findViewById<ImageView>(aiDice[r]).setImageResource(
                            resources.getIdentifier(
                                "die_face_" + aiRand[r],
                                "drawable",
                                packageName
                            )
                        )
                    }
                    println("HUMAN: $humanRand.joinToString()")
                    println("AI: $aiRand.joinToString()")
                    if(humanSum > aiSum){
                        println("HUMAN WINS!!!")
                        println("Score = YOU:${humanSum} / AI:${aiSum}")
                        println("HUMAN: $humanRand.joinToString()")
                        println("AI: $aiRand.joinToString()")
                        findViewById<TextView>(R.id.scoreTxt).text = "Score = YOU:${humanSum} / AI:${aiSum}"
                        StartupActivity.humanWins++
                        findViewById<TextView>(R.id.wins).text = "Wins = YOU:${StartupActivity.humanWins} / AI:${StartupActivity.aiWins}"
                        val b = AlertDialog.Builder(this)
                        b.setTitle(Html.fromHtml("<font color='#4f7942'>You win!</font>"))
                        b.setMessage(Html.fromHtml("<font color='#006400'>You win! with a score of $humanSum against the computer with a score of $aiSum.</font>"))
                        b.setPositiveButton("OK"){_,_->this.finish()}
                        b.create().show()
                        findViewById<Button>(R.id.throwBtn).isClickable = false
                        findViewById<Button>(R.id.score).isClickable = false
                    }else if(aiSum > humanSum){
                        println("AI WINS!!!")
                        findViewById<TextView>(R.id.scoreTxt).text = "Score = YOU:${humanSum} / AI:${aiSum}"
                        println("Score = YOU:${humanSum} / AI:${aiSum}")
                        println("HUMAN: $humanRand.joinToString()")
                        println("AI: $aiRand.joinToString()")
                        StartupActivity.aiWins++
                        findViewById<TextView>(R.id.wins).text = "Wins = YOU:${StartupActivity.humanWins} / AI:${StartupActivity.aiWins}"
                        val b = AlertDialog.Builder(this)
                        b.setTitle(Html.fromHtml("<font color='#ff0000'>You lose.</font>"))
                        b.setMessage(Html.fromHtml("<font color='#ff0000'>You lose with a score of $humanSum against the computer with a score of $aiSum.</font>"))
                        b.setPositiveButton("OK"){_,_->this.finish()}
                        b.create().show()
                        findViewById<Button>(R.id.throwBtn).isClickable = false
                        findViewById<Button>(R.id.score).isClickable = false
                    }
                }

            }else{
                if(humanReRollToggle == 0 && aiReRollToggle == 0) {
                    println("NEW TURN")
                    humanRand = IntArray(5) { Random.nextInt(1, 7) }.asList().toMutableList()
                    aiRand = IntArray(5) { Random.nextInt(1, 7) }.asList().toMutableList()
                    humanSum += humanRand.sum()
                    aiSum += aiRand.sum()
                    println("HUMAN: $humanRand.joinToString()")
                    println("AI: $aiRand.joinToString()")
                    displayDie()
                    humanReRolls = 2
                    aiReRolls = 2
                    humanRolls++
                    aiRolls++
                    findViewById<TextView>(R.id.rolls).text = "Rolls = YOU:$humanRolls / AI:$aiRolls"
                }else{
                    println("RE-ROLL POSSIBLE")
                    if(eT.isEmpty()){
                        noInput()
                    }
                    if(humanReRollToggle == 1 && eT.isNotEmpty()) {
                        humanReRolling()
                    }
                    if(aiReRollToggle == 1) {
                        aiReRolling()
                    }
                    humanReRollToggle = 0
                    aiReRollToggle = 0
                }
            }
        }
        //THROW BUTTON click event listener END

        //SCORE BUTTON click event listener START
        findViewById<Button>(R.id.score).setOnClickListener{
            scorePressed++
            findViewById<TextView>(R.id.scoreTxt).text = "Score = YOU:${humanSum} / AI:${aiSum}"
            println("Score = YOU:${humanSum} / AI:${aiSum}")
            if(humanSum > 0 && aiSum > 0) {
                if (humanSum >= goal && (aiSum < humanSum)) {
                    StartupActivity.humanWins++
                    findViewById<TextView>(R.id.wins).text =
                        "Wins = YOU:${StartupActivity.humanWins} / AI:${StartupActivity.aiWins}"
                    val builder = AlertDialog.Builder(this)
                    builder.setTitle("You win!")
                    builder.setMessage("You win! with a score of $humanSum against the computer with a score of $aiSum")
                    builder.setPositiveButton("OK") { _, _ -> this.finish() }
                    builder.create().show()
                    findViewById<Button>(R.id.throwBtn).isClickable = false
                    findViewById<Button>(R.id.score).isClickable = false

                } else if (aiSum >= goal && (humanSum < aiSum)) {
                    StartupActivity.aiWins++
                    findViewById<TextView>(R.id.wins).text =
                        "Wins = YOU:${StartupActivity.humanWins} / AI:${StartupActivity.aiWins}"
                    val builder = AlertDialog.Builder(this)
                    builder.setTitle("You lose.")
                    builder.setMessage("You lose with a score of $humanSum against the computer with a score of $aiSum")
                    builder.setPositiveButton("OK") { _, _ -> this.finish() }
                    builder.create().show()
                    findViewById<Button>(R.id.throwBtn).isClickable = false
                    findViewById<Button>(R.id.score).isClickable = false
                } else if(humanSum == aiSum && (aiSum >= goal && humanSum >= goal)){
                    Toast.makeText(applicationContext, "Equal scores and rolls, all dice will be re-rolled", Toast.LENGTH_SHORT).show()
                    while(humanSum > aiSum || aiSum > humanSum) {
                        for (r in humanRand.indices) {
                            humanSum -= humanRand[r]
                            humanRand[r] = Random.nextInt(1, 7)
                            humanSum += humanRand[r]
                            findViewById<ImageView>(humanDice[r]).setImageResource(
                                resources.getIdentifier(
                                    "die_face_" + humanRand[r],
                                    "drawable",
                                    packageName
                                )
                            )
                        }
                        for (r in aiRand.indices) {
                            aiSum -= aiRand[r]
                            aiRand[r] = Random.nextInt(1, 7)
                            aiSum += aiRand[r]
                            findViewById<ImageView>(aiDice[r]).setImageResource(
                                resources.getIdentifier(
                                    "die_face_" + aiRand[r],
                                    "drawable",
                                    packageName
                                )
                            )
                        }
                    }
                }else {
                    if (humanReRolls > 0 && humanReRollToggle == 0) {
                        humanReRoll()
                    }
                    if (aiReRolls > 0 && aiReRollToggle == 0) {
                        //50% probability that AI re-rolls a die
                        val aiR = IntArray(2) { Random.nextInt(0, 2) }
                        for (i in aiR) {
                            if (i == 1) {
                                aiReRolls--
                                aiReRollToggle = 1

                            }
                        }
                    }

                    //Message for the user to be informed that they must pressed the "Throw" button to re-roll START
                    if (humanReRollToggle == 1 || aiReRollToggle == 1) {
                        Toast.makeText(
                            applicationContext,
                            "Please press the 'Throw' button",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                    //Message for the user to be informed that they must pressed the "Throw" button to re-roll END

                    //Message for the user to be informed that they or the AI can't re-roll any dice anymore START
                    if (aiReRolls == 0 || humanReRolls == 0) {
                        Toast.makeText(
                            applicationContext,
                            "No ${if(aiReRolls == 0)"AI" else if (humanReRolls == 0)"human" else  "human or AI"} re-rolls left in this turn (2 per turn) (Press the 'Throw' for the next turn)",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                    //Message for the user to be informed that the AI can't re-roll any dice anymore END
                }
            }
        }
    }
    //THROW BUTTON click event listener END

    //Function for changing die faces START
    @SuppressLint("DiscouragedApi")
    fun displayDie(){
        for(r in humanRand.indices){
            println("die_face_"+humanRand[r])
            findViewById<ImageView>(humanDice[r]).setImageResource(resources.getIdentifier("die_face_"+humanRand[r],"drawable",packageName))
        }
        for(r in aiRand.indices){
            println("die_face_"+aiRand[r])
            findViewById<ImageView>(aiDice[r]).setImageResource(resources.getIdentifier("die_face_"+aiRand[r],"drawable",packageName))
        }
    }
    //Function for changing die faces END

    //HUMAN re-roll prompt function START
    @SuppressLint("DiscouragedApi")
    private fun humanReRoll(){
        val b = AlertDialog.Builder(this)
        val i= layoutInflater
        b.setTitle("Enter no. for which dice to not re-roll (separate with comma(,))")
        val dL = i.inflate(R.layout.prompt, null)
        val editT = dL.findViewById<EditText>(R.id.input)
        b.setView(dL)
        b.setPositiveButton("OK"){_,_->
            if(editT.text.isNotEmpty()){
                humanReRolls--
                eT = editT.text.toString()
                humanReRollToggle = 1
            }else{
                eT = ""
            }
        }
        b.create().show()
    }
    //HUMAN re-roll prompt function END

    //HUMAN re-roll function START
    @SuppressLint("DiscouragedApi")
    private fun humanReRolling(){
        if(humanReRolls == 0) {
            println("Score = YOU:${humanSum} / AI:${aiSum}")
        }
        val eTText: List<Int>
        if(eT.isNotEmpty()) {
            eTText = eT.split(",").map {it.toInt()}
            for (r in humanRand.indices) {
                for (e in eTText) {
                    if (resources.getResourceEntryName(humanDice[r])
                            .split("")[resources.getResourceEntryName(humanDice[r]).length].toInt() !in eTText
                    ) {
                        println(
                            "HUMAN Re-roll: $e ${
                                resources.getResourceEntryName(humanDice[r])
                                    .split("")[resources.getResourceEntryName(humanDice[r]).length]
                            }"
                        )
                        humanSum-=humanRand[r]
                        humanRand[r] = Random.nextInt(1, 7)
                        humanSum+=humanRand[r]
                        findViewById<ImageView>(humanDice[r]).setImageResource(
                            resources.getIdentifier(
                                "die_face_" + humanRand[r],
                                "drawable",
                                packageName
                            )
                        )
                    }
                }
            }
        }
        if(humanReRolls == 0){
            println("Score = YOU:${humanSum} / AI:${aiSum}")
            findViewById<TextView>(R.id.scoreTxt).text = "Score = YOU:${humanSum} / AI:${aiSum}"
        }
    }
    //HUMAN re-roll function END

    //Function to re-roll all dice in case of no input START
    @SuppressLint("DiscouragedApi")
    private fun noInput(){
        Toast.makeText(applicationContext, "No input, all dice will be re-rolled", Toast.LENGTH_SHORT).show()
        for (r in humanRand.indices) {
            humanSum-=humanRand[r]
            humanRand[r] = Random.nextInt(1, 7)
            humanSum+=humanRand[r]
            findViewById<ImageView>(humanDice[r]).setImageResource(
                resources.getIdentifier(
                    "die_face_" + humanRand[r],
                    "drawable",
                    packageName
                )
            )
        }
        humanReRollToggle = 1
    }
    //Function to re-roll all dice in case of no input END

    //AI re-roll function START
    @SuppressLint("DiscouragedApi")
    private fun aiReRolling(){
        for(r in aiDice.indices){
            //50% probability that AI re-rolls a die
            if(Random.nextInt(0,2) == 1){
                println(
                    "AI Re-roll: ${
                        resources.getResourceEntryName(aiDice[r])
                            .split("")[resources.getResourceEntryName(aiDice[r]).length]
                    }"
                )
                aiSum-=aiRand[r]
                aiRand[r] = Random.nextInt(1, 7)
                aiSum+=aiRand[r]
                findViewById<ImageView>(aiDice[r]).setImageResource(
                    resources.getIdentifier(
                        "die_face_" + aiRand[r],
                        "drawable",
                        packageName
                    )
                )
            }
        }
    }

    //AI re-roll function END
}

//References:
//Die face images: https://www.wpclipart.com/recreation/games/dice/
//Prompt: https://www.digitalocean.com/community/tutorials/android-alert-dialog-using-kotlin
//getResource: https://stackoverflow.com/questions/10137692/how-to-get-resource-name-from-resource-id
//getIdentifier: https://stackoverflow.com/questions/3476430/how-to-get-a-resource-id-with-a-known-resource-name
//Portrait orientation: https://stackoverflow.com/questions/582185/how-can-i-disable-landscape-mode-in-android