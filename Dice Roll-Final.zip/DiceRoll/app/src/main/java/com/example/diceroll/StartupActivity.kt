package com.example.diceroll

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.ActionBar
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

class StartupActivity : AppCompatActivity() {
    //variables that allow continuity between activities START
    companion object {
        var humanWins:Int = 0
        var aiWins:Int = 0
    }
    //variables that allow continuity between activities END

    //function that runs when a activity has started START
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.startup)
        val aB : ActionBar? = supportActionBar
        aB?.hide()

        //"About" button click event listener START
        findViewById<Button>(R.id.about).setOnClickListener {
            val b = AlertDialog.Builder(this)
            b.setMessage("Name: Lesnar Dsilva\n Student ID: w18630169\n\nI confirm that I understand what plagiarism is and have read and understood the section on Assessment Offences in the Essential Information for Students. The work that I have submitted is entirely my own. Any work from other authors is duly referenced and acknowledged.")
            b.create().show()
        }
        //"About" button click event listener END
        
        //"New Game" button click event listener START
        findViewById<Button>(R.id.newGame).setOnClickListener {
            val b = AlertDialog.Builder(this)
            val i = layoutInflater
            b.setTitle("Enter goal for score")
            val dL = i.inflate(R.layout.prompt, null)
            val editT = dL.findViewById<EditText>(R.id.input)
            b.setView(dL)
            b.setPositiveButton("OK"){_,_->
                if(editT.text.isNotEmpty() && editT.text.toString().filter { it.isDigit() }.toInt() > 5){
                    //user specified goal for game score
                    Main.goal = editT.text.toString().filter { it.isDigit() }.toInt()
                    startActivity(Intent(this, Main::class.java))
                }else{
                    //default goal for game score
                    Main.goal = 101
                    startActivity(Intent(this, Main::class.java))
                }
            }
            b.create().show()

        }
        //"New Game" button click event listener END
    }
    //function that runs when a activity has started END
}

//DAY 1 = 16/02/2023
//1. Added a "New Game" button.
//2. Added a "About" button.
//3. Created a new Empty Activity which will act as the game screen.
//4. Added a "Throw" button to the main activity.
//5. Added a "Score" button to the main activity.
//6. Added 5 dice for the player.
//7. Added 5 dice for the computer.
//8. Implemented functionality that rolls the dice for the player and computer to the "Throw" button.

//NOTE: Implement the "Score" button's functionality.

//9. Implemented "Score" buttons totaling feature to display the score.
//10. Create a new layout for the prompt.
//11. Now when the "Score" button is pressed a prompt is displayed asking the user to enter the no. for which dice to not be rolled.
//12. The player is only allowed 2 re-rolls per turn, the re-rolls reset to 2 when the user presses the "Throw" button.
//13. The score updates by subtracting the original integer from the sum and assigning a new value in it's place and adding that to the sum.
//14. Moved function for re-rolls from the "Score" button to the "Throw" button to meet specification

//DAY 2 = 17/02/2023
//1. The computer can now randomly choose whether it would like to re-roll.
//2. The computer will re-roll a maximum of 2 times, but the rolls only occur depending on a 50/50 probability.
//3. The computer's re-roll can only be triggered if the user presses the "Throw" button
//4. The computer can use up all it's re-rolls, if the probability favours this event when the user presses the "Score" button, otherwise no re-rolls or a single re-roll for the computer's dice is is triggered using only a single re-roll.
//5. The score updates to accommodate the re-rolls by always updating the sum of the random integers stored in a lis, every integer represents a die.

//DAY 3 = 18/02/2023
//1. When a player (human or computer) reaches a score of 101 or more a dialog will pop-up that win say "You win!" (if the human wins), if the computer wins it displays "You lose".
//2. Once a player wins the game in unplayable (the buttons are disabled). In order to start a new game the user needs to press "OK" on the dialog that pops up or press the Android "Back" button to move to the initial screen of the application.
//3. I've implemented a conditional in the throw and score button that would random roll dice for the human player and computer player, if the score and the number of rolls for the players are equal.
//4. Once the player presses on the "New Game" button on the startup page, a dialog shows up that requests the user to enter a value that should be the goal for the game, once this score is reached the win condition is executed for either player.
//5. The number of wins is counted, even if the player goes back to the startup page, unless the player exits the application then it's cleared from memory and the counter returns to 0.
//6.CHECK BELOW FOR MY IMPLEMENTATION OF THE COMPUTER PLAYER RE-ROLL function.
//7. To avoid the application from crashing or returning to the startup page, I only allowed numbers as inputs in the application.

//COMPUTER RE-ROLL FUNCTION:
/*
* For the computer re-rolling, I looped over all the AI dice, then generated a random integer between 0 and 1, I use these values to execute the conditional responsible for the AI re-roll, but only if the random integer generated is 1. There is already a 50/50 probability that a dice is reassigned a value. The dice value in the random integers list representing each dice, is subtracted from the score sum of the AI player's score, then the value (list element) is reassigned a value from between 1 and 6, and that value is added to the AI player's score sum and the die face is changed from the old value to the newer assigned value.
*/

//DAY 4 = 19/02/2023
//1. Now the pop-up dialog for the user winning or losing has colored text. I used green for when the human player wins, and red for when the human player loses.
//2. I made the decision to force the orientation of the main application to remain in portrait.

//References:
//Die face images: https://www.wpclipart.com/recreation/games/dice/
//Prompt: https://www.digitalocean.com/community/tutorials/android-alert-dialog-using-kotlin
//getResource: https://stackoverflow.com/questions/10137692/how-to-get-resource-name-from-resource-id
//getIdentifier: https://stackoverflow.com/questions/3476430/how-to-get-a-resource-id-with-a-known-resource-name
//Portrait orientation: https://stackoverflow.com/questions/582185/how-can-i-disable-landscape-mode-in-android